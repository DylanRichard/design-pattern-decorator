package vehicule;

public interface vehicule {
	
	public String getNom();
	
	public String getMarque();
	
	public Double getPrix();
}
