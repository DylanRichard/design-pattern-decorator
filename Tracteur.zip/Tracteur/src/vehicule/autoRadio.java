package vehicule;

public class autoRadio extends TracteurAvecOption {

	public autoRadio(tracteur Tracteur) {
		this.setVehicule(Tracteur);
	}
	
	@Override
	public Double getPrix() {
		// TODO Auto-generated method stub
		return Vehicule.getPrix()+ 4000.00;
	}

}
