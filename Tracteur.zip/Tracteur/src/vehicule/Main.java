package vehicule;

public class Main {

	public static void main(String[] args) {

			quaranteCV QuaranteCV = new quaranteCV();
			vehicule QuaranteCVAvecOption = new Clim(new autoRadio((QuaranteCV)));
			System.out.println("Prix : " + QuaranteCVAvecOption.getPrix());
	}
}
