package vehicule;

public class quaranteCV extends tracteur {
	public quaranteCV() {
		this.setNom("quaranteCV");
		this.setMarque("John Deere");
	}

	public Double getPrix() {
		return 60000.00;
	}

}
