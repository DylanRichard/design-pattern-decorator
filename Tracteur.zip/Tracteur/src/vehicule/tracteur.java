package vehicule;

public abstract class tracteur implements vehicule {
	
	private String vehiculeNom;
	private String vehiculeMarque;

	protected void setNom(String Nom) {
		this.vehiculeNom = Nom;
	}

	public String getNom() {
		return this.vehiculeNom;
	}

	protected void setMarque(String Marque) {
		this.vehiculeMarque = Marque;
	}

	public String getMarque() {
		return this.vehiculeMarque;
	}
}
