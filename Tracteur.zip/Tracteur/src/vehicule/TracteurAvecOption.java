package vehicule;

public abstract class TracteurAvecOption extends tracteur {
	
	protected vehicule Vehicule;

	protected void setVehicule(vehicule pVehicule) {
		this.Vehicule = pVehicule;
	}

	public vehicule getVehicule() {
		return this.Vehicule;
	}
}
