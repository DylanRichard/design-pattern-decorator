package vehicule;

public class Clim extends TracteurAvecOption {
	
	public Clim(tracteur Tracteur) {
		this.setVehicule(Tracteur);
	}

	@Override
	public Double getPrix() {
		return Vehicule.getPrix()+3000.00;
	}
}
