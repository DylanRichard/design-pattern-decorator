package Creation;

public class Salade extends decoration{
	
	
	public Salade(Kebab newKebab) {
		super(newKebab);
		
	}
	
	public String getIngredient() {
		return notreKebab.getIngredient() + ", salade";
	}
	
	public Double getPrix() {
		System.out.println("prix de la salade: " + 0.30);
		
		return notreKebab.getPrix()+0.30;
	}

}
