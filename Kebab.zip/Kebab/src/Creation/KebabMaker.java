package Creation;

public class KebabMaker {

	public static void main(String[] args) {
		Kebab kebabSaladeTomateOignon = new Salade(new tomate(new oignon(new pain())));
		
		System.out.println("Ingr�dients : " + kebabSaladeTomateOignon.getIngredient());
		
		System.out.println("Prix du kebab: " + kebabSaladeTomateOignon.getPrix());
	}

}
