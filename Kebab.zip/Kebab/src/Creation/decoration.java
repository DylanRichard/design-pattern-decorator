package Creation;

public abstract class decoration implements Kebab {
	
	protected Kebab notreKebab;
	
	public decoration(Kebab newKebab) {
		notreKebab = newKebab;
	}
	
	public String getDescription() {
		return notreKebab.getIngredient();
	}
	
	public Double getCost() {
		return notreKebab.getPrix();
	}

}
