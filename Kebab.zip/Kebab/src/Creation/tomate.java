package Creation;

public class tomate extends decoration{
	
	
	public tomate(Kebab newKebab) {
		super(newKebab);
		
	}
	
	public String getIngredient() {
		return notreKebab.getIngredient() + ", tomate";
	}
	
	public Double getPrix() {
		System.out.println("prix de la tomate: " + 0.20);
		
		return notreKebab.getPrix()+0.20;
	}

}
