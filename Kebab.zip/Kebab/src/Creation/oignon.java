package Creation;

public class oignon extends decoration{
	
	public oignon(Kebab newKebab) {
		super(newKebab);	
	}
	
	public String getIngredient() {
		return notreKebab.getIngredient() + ", oignon";
	}
	
	public Double getPrix() {
		System.out.println("prix de l'oignon: " + 0.20);
		
		return notreKebab.getPrix()+0.20;
	}

}
