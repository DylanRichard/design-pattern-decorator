package Creation;

public class pain implements Kebab {
	
	public String getIngredient() {
		return "Pita";
	}
	
	public Double getPrix() {
		System.out.println("Prix du pain : " + 1.85 + "�");
		return 1.85;
	}


}
