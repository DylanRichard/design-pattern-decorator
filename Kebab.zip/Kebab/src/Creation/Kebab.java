package Creation;

public interface Kebab {
	
	public String getIngredient();
	
	public Double getPrix();

}

