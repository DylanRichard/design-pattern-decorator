package PasDecorator;

public abstract class Tracteur {

	public abstract void setNom(String newNom);
	
	public abstract void setMarque(String newMarque);
	
	public abstract String getNom();
	
	public abstract String getMarque();
	
	public abstract Integer getPrix();
}
