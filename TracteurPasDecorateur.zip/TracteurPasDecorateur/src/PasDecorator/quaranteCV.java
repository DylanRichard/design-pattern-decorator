package PasDecorator;

public class quaranteCV extends Tracteur{

	@Override
	public void setNom(String newNom) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setMarque(String newMarque) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getNom() {
		return "QuaranteCV";
	}

	@Override
	public String getMarque() {
		return "Kiloutou";
	}

	@Override
	public Integer getPrix() {
		return 60000;
	}
	

}
