package PasDecorator;

public class soixanteCV extends Tracteur{

			@Override
			public void setNom(String newNom) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void setMarque(String newMarque) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public String getNom() {
				return "soixanteCV";
			}

			@Override
			public String getMarque() {
				return "Kiloutou";
			}

			@Override
			public Integer getPrix() {
				return 80000;
			}
}
